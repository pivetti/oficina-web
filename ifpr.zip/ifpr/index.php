<?php
    //mudar timezone do xampp: xampp -> php -> php.ini -> date_timezone -> mudar para America/Sao_paulo
    $campus = "dos Goytacazes";
    $anoAtual = date("Y"); //date pega a data do seu servidor
    $horaAtual = date("h");
    $anoFundacao = 2008;
    $nomeVisitante = $_GET["nome"] ?? "User";
    $cursos = [
        "Administração",
        "Ciências Biológicas",
        "Direito",
        "Sistemas de Informação",
        "Artes Visuais"
    ];

?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>IFPR - Campus <?php echo $campus ?></title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <header>
        <img src="img/ifpr-logo.png" alt="Logo IFPR" style="max-width: 200px;">
        <p>Campus <?php echo $campus ?></p>
    </header>

    <div class="container">
        <h1>
        <?php
            if ($horaAtual < 12){
                echo "Bom dia!";
            } else if ($horaAtual < 18){
                echo "Boa tarde!";
            } else {
                echo "Boa noite!";
            }
            echo " " . $nomeVisitante;
        ?>
        </h1>
        <p>O IFPR oferece cursos técnicos, superiores e de pós-graduação gratuitos e de qualidade.</p>
        <p>#IFPR É federal! É de graça! É a sua cara!  <?php echo ($anoAtual - $anoFundacao); ?> </p>

        <h2>Nossos Cursos</h2>
        <?php
            foreach($cursos as $curso){
                echo "<div class='curso-card'><strong>" . $curso . "</strong></div>";
            }
        ?>

    <footer>
        <p>Copyright &copy; <?php echo $anoAtual; ?> IFPR Campus <?php echo $campus; ?></p>
        <p>Hora atual <?php echo date("H:i");?></p> 
    </footer>

</body>
</html>
